char num2char(int i);
int strLen(char* str);
int intLength(int num);
char* int2str(int num, int length);
char* strConcat(char* str1, char* str2);
int strComp(char* str1, char* str2);
int inArray(int val, int* arr);
void print(char* str);
int strCopy(char* str, char* str2);